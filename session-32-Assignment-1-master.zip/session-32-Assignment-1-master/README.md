# session-32-Assignment-1
DATA ANALYTICS WITH R, EXCEL AND TABLEAU SESSION 32 ASSIGNMENT 1
SESSION 32: TABLEAU DESKTOP
Assignment 1


5. Problem Statement 
1. Import the Super store excel data into MySQL and store the data across three tables orders, people and returns 
2. Connect Tableau Desktop to MySQL database 
3. Import the joined data set of the aforesaid three tables through custom SQL 
4. Rename the data connection as ‘my super store data’ 
5. Create an extract out of the data connection 
6. Save the workbook as Super store dashboard. twbx 

Answer: -
	
1) Download the sample super stores from the link provided by Acadgild (2014 -2017 data)
2) The file consists of three sheets namely orders, returns and people.
3) Save each sheet as comma delimited CSV files by the names orders, returns and people.
4) Open MySQL workbench and login to the same.
5) Create a global superstore schema
6) From global superstore schema import the individual sheets namely orders, returns and people. Step by step procedures as screen shot is given below
7) Login to MySQL 8.0 command line and check the database and tables are imported
8) Connect to Tableau Desktop and open connection
9) Select My SQL connection and import the global superstores
10) Drag orders table to the Tableau worksheet
11) Similarly drag other tables and perform a union of all these tables
12) Update and connect to the extract from live connection.
13) Rename the global super store file as My super store data
14) Create and extract connection and save the work book as super store dashboard.twbx file in the Tableau Repository workbook.
15) This file can be further used for other assignments as this extract contains all the required data.
16) Step by step procedure is captured as screen shot and shown in this file below.
